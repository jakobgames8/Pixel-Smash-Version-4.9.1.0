// Auto-generated code. Do not edit.
namespace myTiles {
    //% fixedInstance jres blockIdentity=images._tile
    export const transparency16 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile1 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile2 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile3 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile4 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile5 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile6 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile7 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile8 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile13 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile10 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile11 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile12 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile14 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile15 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile16 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile17 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile18 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile19 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile9 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile20 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile21 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const transparency8 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile22 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile23 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile24 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile25 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile29 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile32 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile33 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile34 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile35 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile28 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile36 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile37 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile38 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile39 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile40 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile41 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile42 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile43 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile44 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile45 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile46 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile48 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile49 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile47 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile50 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile51 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile53 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile54 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile52 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile31 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile55 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile56 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile57 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile30 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile58 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile59 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile60 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile61 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile62 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile63 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile64 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile65 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile66 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile67 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile68 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile69 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile26 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile27 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile71 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile72 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile73 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile74 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile75 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile76 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile77 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile78 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile79 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile80 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile81 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile82 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile83 = image.ofBuffer(hex``);
    //% fixedInstance jres blockIdentity=images._tile
    export const tile84 = image.ofBuffer(hex``);

    helpers._registerFactory("tilemap", function(name: string) {
        switch(helpers.stringTrim(name)) {
            case "level1":
            case "level1":return tiles.createTilemap(hex`1000100003030303030303030303030303030303030102010102020202020202020202030302020202020202020201010202020303020202020202020202020202020103030202020a06070202010202020201030302020a0d0d0e0202020202020201030302060606060f0202020202020202030304020202020202020a0606070202030606060702020202060b0c0c080202030d0d0d0d0702020202020202020202030d0d0d0d0d07020202020202020502030d0d0d0d0d0d060606060606060606060d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d0d`, img`
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . 2 2 2 . . . . . . . . . 
. . . 2 2 2 2 . . . . . . . . . 
. . 2 2 2 2 2 . . . . . . . . . 
. . . . . . . . . 2 2 2 2 . . . 
2 2 2 2 . . . . 2 2 2 2 2 . . . 
2 2 2 2 2 . . . . . . . . . . . 
2 2 2 2 2 2 . . . . . . . . . . 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
`, [myTiles.transparency16,myTiles.tile1,myTiles.tile2,myTiles.tile3,myTiles.tile4,myTiles.tile5,myTiles.tile10,myTiles.tile11,myTiles.tile12,myTiles.tile13,myTiles.tile14,myTiles.tile15,myTiles.tile16,myTiles.tile17,myTiles.tile18,myTiles.tile19], TileScale.Sixteen);
            case "level3":
            case "level3":return tiles.createTilemap(hex`1000100001010101010101010101010101010101010303030303030303030303030303010103030303030303030303030303030101030303030303030303030303030301010303030303030303030303030303010103030303030303030303030303030101030403030303030303030303050301010202030303030303030303030202010103030303030303030303030303030101070303030302020202030303030601020202020303030303030303020202020202020202030303030303020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202`, img`
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
2 2 2 . . . . . . . . . . 2 2 2 
. . . . . . . . . . . . . . . . 
. . . . . . 2 2 2 2 . . . . . . 
2 2 2 2 . . . . . . . . 2 2 2 2 
2 2 2 2 2 . . . . . . 2 2 2 2 2 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
`, [myTiles.transparency16,myTiles.tile3,myTiles.tile6,myTiles.tile7,myTiles.tile4,myTiles.tile5,myTiles.tile9,myTiles.tile20], TileScale.Sixteen);
            case "level5":
            case "level5":return tiles.createTilemap(hex`1000100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000`, img`
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
`, [myTiles.transparency16], TileScale.Sixteen);
            case "level2":
            case "level2":return tiles.createTilemap(hex`1000100001010101010101010101010101010101010707070707070707070707070707010107070707070707070707070707070101050707070707070707070707070701020202020202020707070707070707010303030303030302070707070707070103030303030303030207070707070701010707070707070707070707070707010107070707020202020202020707070102020202020202020207070707070201010707070707070707070707070707010107070707070707070707040202020201070707070707070707040303030303010707070707070706040303030303030202020202020202020303030303030303030303030303030303030303030303`, img`
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
2 2 2 2 2 2 2 . . . . . . . . . 
2 2 2 2 2 2 2 2 . . . . . . . . 
2 2 2 2 2 2 2 2 2 . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . 2 2 2 2 2 2 2 . . . . 
2 2 2 2 2 2 2 2 2 . . . . . 2 . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . 2 2 2 2 2 
. . . . . . . . . . 2 2 2 2 2 2 
. . . . . . . . . 2 2 2 2 2 2 2 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
`, [myTiles.transparency16,myTiles.tile3,sprites.builtin.forestTiles6,sprites.builtin.forestTiles10,sprites.builtin.forestTiles5,myTiles.tile4,myTiles.tile5,sprites.castle.tilePath5], TileScale.Sixteen);
            case "level4":
            case "level4":return tiles.createTilemap(hex`1000100001010101010101010101010101010101010606060606060606060606060606010106060606060606060606060606060101060606060606060606060606060601010606060606060606060606060606010106020606060606060606060603060101060505050505050505050505050601010505050505050505050505050505010106050505050505050505050505060101060606060606060606060606060601010606060606060606060606060606010106060606060606060606060606060104040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404`, img`
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . 2 2 2 2 2 2 2 2 2 2 2 2 . . 
. 2 2 2 2 2 2 2 2 2 2 2 2 2 2 . 
. . 2 2 2 2 2 2 2 2 2 2 2 2 . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
`, [myTiles.transparency16,myTiles.tile3,myTiles.tile4,myTiles.tile5,myTiles.tile8,sprites.builtin.forestTiles10,myTiles.tile21], TileScale.Sixteen);
            case "level14":
            case "level14":return tiles.createTilemap(hex`14000f00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000`, img`
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
`, [myTiles.transparency8], TileScale.Eight);
            case "level16":
            case "level16":return tiles.createTilemap(hex`14000f00010101010101010101010101010101010101010101010101010104010101040101010101010101010101010101010104010401010101010101010101010101010101040404010101010101010101010101010101010401020104010101010101010101010101010101010101020101010101010101010101010101010101010102010101010101010101010101010101010101010303030303030101010101010101010101010303030303030303030301010101010101010103030303030303030303030301010101010101030303030303030303030303030301010101030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303`, img`
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . 2 2 2 2 2 2 . . . . . . 
. . . . . . 2 2 2 2 2 2 2 2 2 2 . . . . 
. . . . . 2 2 2 2 2 2 2 2 2 2 2 2 . . . 
. . . . 2 2 2 2 2 2 2 2 2 2 2 2 2 2 . . 
. . 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
`, [myTiles.transparency8,myTiles.tile42,myTiles.tile43,myTiles.tile45,myTiles.tile46], TileScale.Eight);
            case "level12":
            case "level12":return tiles.createTilemap(hex`14000f00020202020206060606060606060606060606060602020202020606040606060606060606060505060202020202060606060606060406060606050506020202020206060606060606060606050505050602020202020606060606060606060505050506060202020202060606040606060606050505060606020202020206060606060606060606060606060602020202020101060606060606060606060606060202020202010101060606060606060606060606020202020201010106060606060606060603030302020202020303030303030303030303030303030202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202`, img`
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
2 2 2 2 2 . . . . . . . . . . . . . . 2 
2 2 2 2 2 . . . . . . . . . . . . . . 2 
2 2 2 2 2 . . . . . . . . . . . . . . 2 
2 2 2 2 2 . . . . . . . . . . . . . . 2 
2 2 2 2 2 . . . . . . . . . . . . . . 2 
2 2 2 2 2 . . . . . . . . . . . . . . 2 
2 2 2 2 2 2 2 . . . . . . . . . . . . 2 
2 2 2 2 2 2 2 2 . . . . . . . . . . . 2 
2 2 2 2 2 2 2 2 . . . . . . . . . 2 2 2 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
`, [myTiles.transparency8,myTiles.tile36,myTiles.tile43,myTiles.tile44,myTiles.tile25,myTiles.tile45,myTiles.tile55], TileScale.Eight);
            case "level6":
            case "level6":return tiles.createTilemap(hex`14000f00030303030303030303030303030303030303030303030404040404030303030303030303030304040303030303030403030303030303030303030403030303030303030303030303030304030303040303030303030303030303040404040403030304030404030303040303030303030303030303030303030303010101010303030303030101010103030303030101010101010303030301010101010103030303030303030303030303030303030303030303030303030303030303030303030303030303030301010101010101010101010101010101010101010202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202`, img`
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . 2 2 2 2 . . . . . . 2 2 2 2 . . . 
. . 2 2 2 2 2 2 . . . . 2 2 2 2 2 2 . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
`, [myTiles.transparency8,myTiles.tile22,myTiles.tile23,myTiles.tile24,myTiles.tile25,myTiles.tile56,myTiles.tile57], TileScale.Eight);
            case "level9":
            case "level9":return tiles.createTilemap(hex`14000f00020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020101020202020202020202020202010102020202010101010101010101010101010101010202020201010101010101010101010101010101020202020202010101010101010101010101020202020202020202020202020202020202020202020202030303030303030303030303030303030303030304040404040404040404040404040404040404040404040404040404040404040404040404040404`, img`
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . 2 2 . . . . . . . . . . . . 2 2 . . 
. . 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 . . 
. . 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 . . 
. . . . 2 2 2 2 2 2 2 2 2 2 2 2 . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
`, [myTiles.transparency8,myTiles.tile31,myTiles.tile32,myTiles.tile33,myTiles.tile34], TileScale.Eight);
            case "level10":
            case "level10":return tiles.createTilemap(hex`14000f00050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050502030303030303030303030303030303030303040101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101`, img`
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
`, [myTiles.transparency8,myTiles.tile36,myTiles.tile37,myTiles.tile38,myTiles.tile39,myTiles.tile30], TileScale.Eight);
            case "level17":
            case "level17":return tiles.createTilemap(hex`1000100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000`, img`
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
`, [myTiles.transparency16], TileScale.Sixteen);
            case "level13":
            case "level13":return tiles.createTilemap(hex`14000f00040404020202020202020202020202020202040404040402020202020e0e0e0e02020202020204040404040e0e0e02020e0e0e0e02020e0e0e020404040c0409090202020202020202020e0e02090d04060606060608020202020202020202020a060606060406040608040304040404030404020a060606060606060608020302020202030202020a0606040606060606080203020e0e02030202020a060606060606060608020302020202030202020a06060606060b060608010301010101030201010a06070605050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505050505`, img`
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
2 2 2 2 2 . . . . . . . . . . . . 2 2 2 
. . . . . . 2 . 2 2 2 2 . 2 2 . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
`, [myTiles.transparency8,myTiles.tile24,myTiles.tile42,myTiles.tile43,myTiles.tile30,myTiles.tile58,myTiles.tile61,myTiles.tile63,myTiles.tile64,myTiles.tile65,myTiles.tile66,myTiles.tile67,myTiles.tile68,myTiles.tile69,myTiles.tile25], TileScale.Eight);
            case "level11":
            case "level11":return tiles.createTilemap(hex`14000f00030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030304030303030303030303030303030303030303040303030404040404010101010404040404030303030303040301010101010101010101030403030301010101010202020202020202020201010101010202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202`, img`
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . 2 2 2 2 . . . . . . . . 
. . . . . 2 2 2 2 2 2 2 2 2 2 . . . . . 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
`, [myTiles.transparency8,myTiles.tile40,myTiles.tile41,myTiles.tile42,myTiles.tile24], TileScale.Eight);
            case "level15":
            case "level15":return tiles.createTilemap(hex`14000f00030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303020202020202020202020303030303030202020202020202020202020202020303030303020202020202020202020202020202020303030302020202020202020202020202020202020201010202020202020202020202020202020203030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303`, img`
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . 2 2 2 2 2 2 2 2 2 2 . . . . . . 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 . . . . . 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 . . . . 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
`, [myTiles.transparency8,myTiles.tile25,myTiles.tile36,myTiles.tile52], TileScale.Eight);
            case "level8":
            case "level8":return tiles.createTilemap(hex`14000f00020202020202020202020202020202020202020202020202020202020203030202020202020202020202020202020202020202020202020202020202020202030202020202020202020202020302020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020201010101010101010202020202020302020202020202020202020202020202020203020202020202020202020202020202020202020201010101010202020202020202020201010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101`, img`
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . 2 2 2 2 2 2 2 2 . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . . . . . 
2 2 2 2 2 . . . . . . . . . . 2 2 2 2 2 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
`, [myTiles.transparency8,myTiles.tile29,myTiles.tile30,myTiles.tile57], TileScale.Eight);
            case "level7":
            case "level7":return tiles.createTilemap(hex`14000f00020202020202020202020202020202020202020202020202020202020202020202020202020202020208090909090909090909090909090909090a02020400000000000000000000000000000000030202040000000000000000000000000000000003020204000000000000000000000000000000000302020400000000000000000000000000000000030202040000000000000000000000000000000003020207010c0c05000000000000000006010c0c0b020202020202070c0101010101010c0b020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202`, img`
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
2 . . . . . . . . . . . . . . . . . . 2 
2 . . . . . . . . . . . . . . . . . . 2 
2 . . . . . . . . . . . . . . . . . . 2 
2 . . . . . . . . . . . . . . . . . . 2 
2 . . . . . . . . . . . . . . . . . . 2 
2 . . . . . . . . . . . . . . . . . . 2 
2 . . . . . . . . . . . . . . . . . . 2 
2 2 2 2 2 . . . . . . . . . . 2 2 2 2 2 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
`, [myTiles.transparency8,myTiles.tile26,myTiles.tile27,myTiles.tile71,myTiles.tile73,myTiles.tile75,myTiles.tile77,myTiles.tile78,myTiles.tile79,myTiles.tile80,myTiles.tile81,myTiles.tile82,myTiles.tile83], TileScale.Eight);
            case "level18":
            case "level18":return tiles.createTilemap(hex`1000100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000`, img`
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
`, [myTiles.transparency16], TileScale.Sixteen);
            case "level19":
            case "level19":return tiles.createTilemap(hex`1000100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000`, img`
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
`, [myTiles.transparency16], TileScale.Sixteen);
        }
        return null;
    })

    helpers._registerFactory("tile", function(name: string) {
        switch(helpers.stringTrim(name)) {
            case "transparency16":return transparency16;
            case "myTile":
            case "tile1":return tile1;
            case "myTile0":
            case "tile2":return tile2;
            case "myTile1":
            case "tile3":return tile3;
            case "myTile2":
            case "tile4":return tile4;
            case "myTile3":
            case "tile5":return tile5;
            case "myTile4":
            case "tile6":return tile6;
            case "myTile5":
            case "tile7":return tile7;
            case "myTile6":
            case "tile8":return tile8;
            case "myTile11":
            case "tile13":return tile13;
            case "myTile8":
            case "tile10":return tile10;
            case "myTile9":
            case "tile11":return tile11;
            case "myTile10":
            case "tile12":return tile12;
            case "myTile12":
            case "tile14":return tile14;
            case "myTile13":
            case "tile15":return tile15;
            case "myTile14":
            case "tile16":return tile16;
            case "myTile15":
            case "tile17":return tile17;
            case "myTile16":
            case "tile18":return tile18;
            case "myTile17":
            case "tile19":return tile19;
            case "myTile7":
            case "tile9":return tile9;
            case "myTile18":
            case "tile20":return tile20;
            case "myTile19":
            case "tile21":return tile21;
            case "transparency8":return transparency8;
            case "myTile20":
            case "tile22":return tile22;
            case "myTile21":
            case "tile23":return tile23;
            case "myTile22":
            case "tile24":return tile24;
            case "myTile23":
            case "tile25":return tile25;
            case "myTile27":
            case "tile29":return tile29;
            case "myTile30":
            case "tile32":return tile32;
            case "myTile31":
            case "tile33":return tile33;
            case "myTile32":
            case "tile34":return tile34;
            case "myTile33":
            case "tile35":return tile35;
            case "myTile26":
            case "tile28":return tile28;
            case "myTile34":
            case "tile36":return tile36;
            case "myTile35":
            case "tile37":return tile37;
            case "myTile36":
            case "tile38":return tile38;
            case "myTile37":
            case "tile39":return tile39;
            case "myTile38":
            case "tile40":return tile40;
            case "myTile39":
            case "tile41":return tile41;
            case "myTile40":
            case "tile42":return tile42;
            case "myTile41":
            case "tile43":return tile43;
            case "myTile42":
            case "tile44":return tile44;
            case "myTile43":
            case "tile45":return tile45;
            case "myTile44":
            case "tile46":return tile46;
            case "myTile46":
            case "tile48":return tile48;
            case "myTile47":
            case "tile49":return tile49;
            case "myTile45":
            case "tile47":return tile47;
            case "myTile48":
            case "tile50":return tile50;
            case "myTile49":
            case "tile51":return tile51;
            case "myTile51":
            case "tile53":return tile53;
            case "myTile52":
            case "tile54":return tile54;
            case "myTile50":
            case "tile52":return tile52;
            case "myTile29":
            case "tile31":return tile31;
            case "myTile53":
            case "tile55":return tile55;
            case "myTile54":
            case "tile56":return tile56;
            case "myTile55":
            case "tile57":return tile57;
            case "myTile28":
            case "tile30":return tile30;
            case "myTile56":
            case "tile58":return tile58;
            case "myTile57":
            case "tile59":return tile59;
            case "myTile58":
            case "tile60":return tile60;
            case "myTile59":
            case "tile61":return tile61;
            case "myTile60":
            case "tile62":return tile62;
            case "myTile61":
            case "tile63":return tile63;
            case "myTile62":
            case "tile64":return tile64;
            case "myTile63":
            case "tile65":return tile65;
            case "myTile64":
            case "tile66":return tile66;
            case "myTile65":
            case "tile67":return tile67;
            case "myTile66":
            case "tile68":return tile68;
            case "myTile67":
            case "tile69":return tile69;
            case "myTile24":
            case "tile26":return tile26;
            case "myTile25":
            case "tile27":return tile27;
            case "myTile69":
            case "tile71":return tile71;
            case "myTile70":
            case "tile72":return tile72;
            case "myTile71":
            case "tile73":return tile73;
            case "myTile72":
            case "tile74":return tile74;
            case "myTile73":
            case "tile75":return tile75;
            case "myTile74":
            case "tile76":return tile76;
            case "myTile75":
            case "tile77":return tile77;
            case "myTile76":
            case "tile78":return tile78;
            case "myTile77":
            case "tile79":return tile79;
            case "myTile78":
            case "tile80":return tile80;
            case "myTile79":
            case "tile81":return tile81;
            case "myTile80":
            case "tile82":return tile82;
            case "myTile81":
            case "tile83":return tile83;
            case "myTile82":
            case "tile84":return tile84;
        }
        return null;
    })

}
// Auto-generated code. Do not edit.
