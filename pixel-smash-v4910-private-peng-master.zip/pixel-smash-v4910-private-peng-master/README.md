 


> Open this page at [https://pixeldoodlezzzzzz.github.io/pixel-smash-v4910-private-peng/](https://pixeldoodlezzzzzz.github.io/pixel-smash-v4910-private-peng/)

## Use as Extension

This repository can be added as an **extension** in MakeCode.

* open [https://arcade.makecode.com/](https://arcade.makecode.com/)
* click on **New Project**
* click on **Extensions** under the gearwheel menu
* search for **https://github.com/pixeldoodlezzzzzz/pixel-smash-v4910-private-peng** and import

## Edit this project ![Build status badge](https://github.com/pixeldoodlezzzzzz/pixel-smash-v4910-private-peng/workflows/MakeCode/badge.svg)

To edit this repository in MakeCode.

* open [https://arcade.makecode.com/](https://arcade.makecode.com/)
* click on **Import** then click on **Import URL**
* paste **https://github.com/pixeldoodlezzzzzz/pixel-smash-v4910-private-peng** and click import

## Blocks preview

This image shows the blocks code from the last commit in master.
This image may take a few minutes to refresh.

![A rendered view of the blocks](https://github.com/pixeldoodlezzzzzz/pixel-smash-v4910-private-peng/raw/master/.github/makecode/blocks.png)

#### Metadata (used for search, rendering)

* for PXT/arcade
<script src="https://makecode.com/gh-pages-embed.js"></script><script>makeCodeRender("{{ site.makecode.home_url }}", "{{ site.github.owner_name }}/{{ site.github.repository_name }}");</script>
